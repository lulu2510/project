﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DS;

namespace DAL
{
    public class Dal_imp : Idal
    {


        #region Trainee
        public bool findTrainee(string ID)//פונקציה שבודקת אם התלמיד קיים
        {
            foreach (Trainee trainee in DataSource.trainees)
                if (ID.Equals(trainee.IDTrainee))
                    return true;
            return false;
        }

        public void addTrainee(Trainee T)//data sourceפונקציה שמוסיפה תלמיד ל
        {
            if (!findTrainee(T.IDTrainee) && !findTester(T.IDTrainee)) 
                DataSource.trainees.Add(T);
            else
                throw new Exception("the ID is already exsits");
        }

        public void deleteTrainee(string ID)//פונקציה שמוחקת תלמיד
        {
            if (findTrainee(ID))
            {
                for (int i = 0; i < DataSource.trainees.Count; i++)
                {
                    if (ID.Equals(DataSource.trainees[i].IDTrainee))
                    {
                        DataSource.trainees.RemoveAt(i);
                    }
                }
            }
            else
                throw new Exception("the trainee is not exsits");
        }

        public void updateTrainee(Trainee T)//פונקציה שמעדכנת נתונים של תלמיד
        {
            bool flag = false;
            for (int i = 0; i < DataSource.trainees.Count; i++)
                if (DataSource.trainees[i].IDTrainee == T.IDTrainee)
                {
                    DataSource.trainees[i] = T;
                    flag = true;
                }
            if (!flag)
                throw new Exception("this Trainee is not exist");
        }

        public Trainee getTrainee(string ID)//פונקציה שמחזירה נתונים של תלמיד
        {
            return DataSource.trainees.FirstOrDefault(T => T.IDTrainee == ID);
        }

        public IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null)//פונקציה שמחזירה טבלה של כל תלמידים
        {
            if (predicat == null)
                return DataSource.trainees.AsEnumerable();
            return DataSource.trainees.Where(predicat);
        }
        #endregion
        #region Tester
        public bool findTester(string ID)//פונקציה שבודקת אם הבוחן קיים
        {
            foreach (Tester Tester in DataSource.testers)
                if (ID.Equals(Tester.IDTester))
                    return true;
            return false;
        }

        public void addTester(Tester T)//data sourceפונקציה שמוסיפה בוחן ל
        {
            if (!findTester(T.IDTester)&&!findTrainee(T.IDTester))
                DataSource.testers.Add(T);
            else
                throw new Exception("the ID is already exsits");
        }

        public void deleteTester(string ID)//פונקציה שמוחקת בוחן
        {
            if (findTester(ID))
            {
                for (int i = 0; i < DataSource.testers.Count; i++)
                {
                    if (ID == DataSource.testers[i].IDTester)
                    {
                        DataSource.testers.RemoveAt(i);
                    }
                }
            }
            else
                throw new Exception("the Tester is not exsits");
        }

        public void updateTester(Tester T)//מעדכן תלמיד
        {
            bool flag = false;
            for (int i = 0; i < DataSource.testers.Count; i++)
                if (DataSource.testers[i].IDTester == T.IDTester)
                {
                    DataSource.testers[i] = T;
                    flag = true;
                }
            if (!flag)
                throw new Exception("this Tester is not exist");
        }

        public Tester getTester(string ID)//פונקציה שמחזירה בוחן
        {
            return DataSource.testers.FirstOrDefault(T => T.IDTester == ID);
        }

        public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)//פונקציה שמחזירה טבלה של כל הבוחנים
        {
            if (predicat == null)
                return DataSource.testers.AsEnumerable();
            return DataSource.testers.Where(predicat);
        }

        #endregion
        #region Test
        public bool findTest(string ID)//פונקציה שנחפשת אם המבחן קיים
        {
            foreach (Test Test in DataSource.tests)
                if (ID.Equals(Test.IDTest))
                    return true;
            return false;
        }

        public void addTest(Test T)//פונקציה שמחזירה מבחן
        {
            string id = null;
            for (int j = 8; j > Configuration.TestID.ToString().Length; j--)
            {
                id = id + "0";
            }
            id = id + Configuration.TestID.ToString();
            Configuration.TestID++;
            T.IDTest = id;
            DataSource.tests.Add(T);
        }

        public void updateTest(Test T)//פונקציה שמעדכנת מתונים של המבחן
        {
            bool flag = false;
            for (int i = 0; i < DataSource.tests.Count; i++)
                if (DataSource.tests[i].IDTest == T.IDTest)
                {
                    DataSource.tests[i] = T;
                    flag = true;
                }
            if (!flag)
                throw new Exception("this Test is not exist");
        }

        public Test getTest(string ID)//פונקציה שמחזירה נתונים של מבחן
        {
            return DataSource.tests.FirstOrDefault(T => T.IDTest == ID);
        }

        public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
        {
            if (predicat == null)
                return DataSource.tests.AsEnumerable();
            return DataSource.tests.Where(predicat);
        }
        #endregion 

        public List<Trainee> getListTrainee()
        {
            return DataSource.trainees;
        }

        public List<Tester> getListTester()
        {
            return DataSource.testers;
        }

        public List<Test> getListTest()
        {
            return DataSource.tests;
        }
        public void SetConfig()
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;


namespace DAL
{
    public interface Idal
    {
        #region Trainee
        /* *************
           *  Trainee  *
           *************  */

        bool findTrainee(string ID);//search trainee
        void addTrainee(Trainee T);//add trainee
        void deleteTrainee(string ID);//delete Trainee
        void updateTrainee(Trainee T);//update Trainee
        Trainee getTrainee(string ID);//get Trainee
        IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null);//get All Trainee
        #endregion
        #region Tester
        /* *************
           *  Tester  *
           *************  */

        bool findTester(string ID);//search Tester
        void addTester(Tester T);//add Tester
        void deleteTester(string TesterID);//delete Tester
        void updateTester(Tester T);//update Tester
        Tester getTester(string TesterID);//get Tester
        IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null);//get All Tester
        #endregion
        #region Test
        /* *************
           *   Test    *
           *************  */

        bool findTest(string ID);//search Test
        void addTest(Test T);//add Test
        void updateTest(Test T);//update Test
        Test getTest(string ID);//get Test
        IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null);//get All Test
        #endregion

        List <Trainee> getListTrainee();
        List <Tester>  getListTester();
        List <Test>    getListTest();

        void SetConfig();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BE;
using DS;
using System.IO;
using System.ComponentModel;

namespace DAL
{
    /*
     * public string IDTrainee { get; set; } //Trainee ID
        public string FirstNameTrainee { get; set; } //Trainee First name
        public string LastNameTrainee { get; set; } //Trainee Last name
        public gender TraineeGender { get; set; } //Trainee gender
        public string TraineePhone { get; set; } //Trainee phone
        public adress TraineeAdress { get; set; } //Trainee adress
        public DateTime TraineeBirth { get; set; } //Trainee birth
        public bool[] TraineeCarType { get; set; } //Trainee car type
        public gear TraineeGear { get; set; } //Trainee gear
        TraineeSchool 
        NameTeacher
        LessonCount 
        LastTestDate
        TestCounts*/

    public class Dal_XML_imp : Idal
    {
        #region classes to XML

        List<string> array2DToList(bool[][] arr)
        {
            List<string> str = new List<string>();
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    str.Add(i.ToString() + j.ToString() + arr[i][j].ToString());
                }
            }
            return str;
        }
        List<string> array4DToList(bool[,,,] arr)
        {
            DateTime d;
            List<string> str = new List<string>();
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    for (int m = 0; m < arr.GetLength(2); m++)
                    {
                        for (int n = 0; n < arr.GetLength(3); n++)
                        {
                            //[100,13,32,24]
                            d = new DateTime(2 * 100 + i, j, m, n, 0, 0, 0);
                            str.Add(d.ToString("yyyy/MM/dd HH:mm") + arr[i, j, m, n].ToString());
                        }
                    }
                }
            }
            return str;
        }
        bool[][] listTo2DArray(List<string> s)
        {
            int a, b;
            string sa = null;
            bool[][] arr = { new bool[6], new bool[6], new bool[6], new bool[6], new bool[6] };
            foreach (string str in s)
            {
                a = Convert.ToInt32(str[0]) - 48;
                b = Convert.ToInt32(str[1]) - 48;
                for (int i = 2; i < str.Length; i++)
                {
                    sa = sa + str[i];
                }
                arr[a][b] = Convert.ToBoolean(sa);
                sa = null;
            }
            return arr;
        }
        List<string> XMLToList(XElement p)
        {
            List<string> s = null;
            s = p.Elements().Select(q => q.Value).ToList();

            return s;
        }
        List<DateTime> listToDate(List<string> s)
        {
            List<DateTime> d = new List<DateTime>();
            for (int i = 0; i < s.Count; i++)
            {
                d.Add(Convert.ToDateTime(s[i]));
            }
            return d;
        }
        #endregion
        XElement traineeRoot;
        const string traineePath = @"TraineeXML.xml";

        XElement testerRoot;
        const string testerPath = @"TesterXML.xml";

        XElement testRoot;
        const string testPath = @"TestXML.xml";

        XElement ConfigRoot;
        const string ConfigPath = @"Config.XML";

        public Dal_XML_imp()
        {
            try
            {
                if (!File.Exists(traineePath))
                {
                    traineeRoot = new XElement("Trainees");
                    traineeRoot.Save(traineePath);
                }
                else traineeRoot = XElement.Load(traineePath);
                if (!File.Exists(testerPath))
                {
                    testerRoot = new XElement("Testers");
                    testerRoot.Save(testerPath);
                }
                else testerRoot = XElement.Load(testerPath);
                if (!File.Exists(testPath))
                {
                    testRoot = new XElement("Tests");
                    testRoot.Save(testPath);
                }
                else testRoot = XElement.Load(testPath);
                if (!File.Exists(ConfigPath))
                {
                    ConfigRoot = new XElement("Configuration");
                    ConfigRoot.Save(ConfigPath);
                }
                else ConfigRoot = XElement.Load(ConfigPath);
            }
            catch
            {
                throw new Exception("File upload problem");
            }

        }



        #region Trainee
        /* *************
           *  Trainee  *
           ************* */

        public bool findTrainee(string ID)
        {
            XElement traineeElement;
            traineeElement = (from p in traineeRoot.Elements()
                              where p.Element("IDTrainee").Value == ID
                              select p).FirstOrDefault();
            if (traineeElement == null)
                return false;
            return true;
        }
        public void addTrainee(Trainee T)
        {
            if (findTrainee(T.IDTrainee))
                throw new Exception("The trainee is already exsist in the system");
            XElement IDTrainee = new XElement("IDTrainee", T.IDTrainee);
            XElement FirstNameTrainee = new XElement("FirstNameTrainee", T.FirstNameTrainee);
            XElement LastNameTrainee = new XElement("LastNameTrainee", T.LastNameTrainee);
            XElement TraineeGender = new XElement("TraineeGender", T.TraineeGender);
            XElement TraineePhone = new XElement("TraineePhone", T.TraineePhone);
            XElement TraineeStreet = new XElement("TraineeStreet", T.TraineeAdress.NameOfStreet);
            XElement TraineeNumStreet = new XElement("TraineeNumStreet", T.TraineeAdress.NumOfStreet);
            XElement TraineeCity = new XElement("TraineeCity", T.TraineeAdress.city);
            XElement TraineeBirth = new XElement("TraineeBirth", T.TraineeBirth);
            XElement TraineeCarType = new XElement("TraineeCarType", T.TraineeCarType);
            XElement TraineeGear = new XElement("TraineeGear", T.TraineeGear);
            XElement TraineeSchool = new XElement("TraineeSchool", T.TraineeSchool);
            XElement NameTeacher = new XElement("NameTeacher", T.NameTeacher);
            XElement LessonCount = new XElement("LessonCount", T.LessonCount);
            XElement LastTestDate = new XElement("LastTestDate", T.LastTestDate);
            XElement TestCounts = new XElement("TestCounts", T.TestCounts);
            traineeRoot.Add(new XElement("Trainee", IDTrainee, FirstNameTrainee, LastNameTrainee, TraineeGender, TraineePhone, TraineeStreet, TraineeNumStreet, TraineeCity, TraineeBirth, TraineeCarType, TraineeGear,
                TraineeSchool, NameTeacher, LessonCount, LastTestDate, TestCounts));
            traineeRoot.Save(traineePath);
        }
        public void deleteTrainee(string ID)
        {
            XElement traineeElement;
            traineeElement = (from p in traineeRoot.Elements()
                              where p.Element("IDTrainee").Value == ID
                              select p).FirstOrDefault();
            if (traineeElement == null)
                throw new Exception("The trainee dosen't exsist in the system");
            traineeElement.Remove();
            traineeRoot.Save(traineePath);
        }
        public void updateTrainee(Trainee T)
        {
            XElement traineeElement;
            traineeElement = (from p in traineeRoot.Elements()
                              where p.Element("IDTrainee").Value == T.IDTrainee
                              select p).FirstOrDefault();
            if (traineeElement == null)
                throw new Exception("The trainee dosen't exsist in the system");
            traineeElement.Element("IDTrainee").Value = T.IDTrainee;
            traineeElement.Element("FirstNameTrainee").Value = T.FirstNameTrainee;
            traineeElement.Element("LastNameTrainee").Value = T.LastNameTrainee;
            traineeElement.Element("TraineeGender").Value = T.TraineeGender.ToString();
            traineeElement.Element("TraineePhone").Value = T.TraineePhone;
            traineeElement.Element("TraineeStreet").Value = T.TraineeAdress.NameOfStreet;
            traineeElement.Element("TraineeCity").Value = T.TraineeAdress.city;
            traineeElement.Element("TraineeNumStreet").Value = T.TraineeAdress.NumOfStreet.ToString();
            traineeElement.Element("TraineeBirth").Value = T.TraineeBirth.ToString();
            traineeElement.Element("TraineeCarType").Value = T.TraineeCarType.ToString();
            traineeElement.Element("TraineeGear").Value = T.TraineeGear.ToString();
            traineeElement.Element("TraineeSchool").Value = T.TraineeSchool;
            traineeElement.Element("NameTeacher").Value = T.NameTeacher;
            traineeElement.Element("LessonCount").Value = T.LessonCount.ToString();
            traineeElement.Element("LastTestDate").Value = T.LastTestDate.ToString();
            traineeElement.Element("TestCounts").Value = T.TestCounts.ToString();
            traineeRoot.Save(traineePath);
        }
        public Trainee getTrainee(string ID)
        {
            XElement p;
            p = (from q in traineeRoot.Elements()
                 where q.Element("IDTrainee").Value == ID
                 select q).FirstOrDefault();
            if (p == null)
                throw new Exception("The trainee dosen't exsist in the system");
            Trainee T = new Trainee()
            {
                IDTrainee = ID,
                FirstNameTrainee = p.Element("FirstNameTrainee").Value,
                LastNameTrainee = p.Element("LastNameTrainee").Value,
                TraineeGender = (gender)Enum.Parse(typeof(gender), p.Element("TraineeGender").Value),
                TraineePhone = p.Element("TraineePhone").Value,
                TraineeAdress = new adress(p.Element("TraineeStreet").Value, Convert.ToInt32(p.Element("TraineeNumStreet").Value), p.Element("TraineeCity").Value),
                TraineeBirth = Convert.ToDateTime(p.Element("TraineeBirth").Value),
                TraineeCarType = (carType)Enum.Parse(typeof(carType), p.Element("TraineeCarType").Value),
                TraineeGear = (gear)Enum.Parse(typeof(gear), p.Element("TraineeGear").Value),
                TraineeSchool = p.Element("TraineeSchool").Value,
                NameTeacher = p.Element("NameTeacher").Value,
                LessonCount = Convert.ToInt32(p.Element("LessonCount").Value),
                LastTestDate = Convert.ToDateTime(p.Element("LastTestDate").Value),
                TestCounts = Convert.ToInt32(p.Element("TestCounts").Value)
            };
            return T;
        }
        public IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null)
        {
            IEnumerable<Trainee> trainees;
            try
            {
                trainees = from p in traineeRoot.Elements()
                           select new Trainee()
                           {
                               IDTrainee = p.Element("IDTrainee").Value,
                               FirstNameTrainee = p.Element("FirstNameTrainee").Value,
                               LastNameTrainee = p.Element("LastNameTrainee").Value,
                               TraineeGender = (gender)Enum.Parse(typeof(gender), p.Element("TraineeGender").Value),
                               TraineePhone = p.Element("TraineePhone").Value,
                               TraineeAdress = new adress(p.Element("TraineeStreet").Value, Convert.ToInt32(p.Element("TraineeNumStreet").Value), p.Element("TraineeCity").Value),
                               TraineeBirth = Convert.ToDateTime(p.Element("TraineeBirth").Value),
                               TraineeCarType = (carType)Enum.Parse(typeof(carType), p.Element("TraineeCarType").Value),
                               TraineeGear = (gear)Enum.Parse(typeof(gear), p.Element("TraineeGear").Value),
                               TraineeSchool = p.Element("TraineeSchool").Value,
                               NameTeacher = p.Element("NameTeacher").Value,
                               LessonCount = Convert.ToInt32(p.Element("LessonCount").Value),
                               LastTestDate = Convert.ToDateTime(p.Element("LastTestDate").Value),
                               TestCounts = Convert.ToInt32(p.Element("TestCounts").Value)
                           };
                if (predicat != null)
                {
                    trainees = trainees.Where(predicat);
                }
            }
            catch
            {
                trainees = null;
            }
            return trainees;
        }
        #endregion
        #region Tester
        /* *************
           *  Tester  *
           *************  */

        public bool findTester(string ID)
        {
            XElement testerElement;
            testerElement = (from p in testerRoot.Elements()
                             where p.Element("IDTester").Value == ID
                             select p).FirstOrDefault();
            if (testerElement == null)
                return false;
            return true;
        }
        public void addTester(Tester T)
        {
            XElement IDTester = new XElement("IDTester", T.IDTester);
            XElement LastName = new XElement("LastName", T.LastName);
            XElement FirstName = new XElement("FirstName", T.FirstName);
            XElement TesterGender = new XElement("TesterGender", T.TesterGender);
            XElement Birth = new XElement("Birth", T.Birth);
            XElement PhoneNumber = new XElement("PhoneNumber", T.PhoneNumber);
            XElement TesterStreet = new XElement("TesterStreet", T.TesterAdress.NameOfStreet);
            XElement TesterNumStreet = new XElement("TesterNumStreet", T.TesterAdress.NumOfStreet);
            XElement TesterCity = new XElement("TesterCity", T.TesterAdress.city);
            XElement Reputation = new XElement("Reputation", T.Reputation);
            XElement MaxTestsPerWeek = new XElement("MaxTestsPerWeek", T.MaxTestsPerWeek);
            XElement FavoriteTester = new XElement("FavoriteTester", T.FavoriteTester);
            List<string> str = null;
            str = array2DToList(T.WorkTime);
            XElement WorkTime = new XElement("WorkTime", str.Select(i => new XElement("Time", i)));
            XElement MaxDistance = new XElement("MaxDistance", T.MaxDistance);
            XElement TestDates = new XElement("TestDates");
            testerRoot.Add(new XElement("Tester", IDTester, LastName, FirstName, TesterGender, Birth, PhoneNumber, TesterStreet, TesterNumStreet, TesterCity, Reputation, MaxTestsPerWeek, FavoriteTester, WorkTime, MaxDistance, TestDates));
            testerRoot.Save(testerPath);
        }
        public void deleteTester(string TesterID)
        {
            XElement testerElement;
            testerElement = (from p in testerRoot.Elements()
                             where p.Element("IDTester").Value == TesterID
                             select p).FirstOrDefault();
            if (testerElement == null)
                throw new Exception("The tester dosen't exsist in the system");
            testerElement.Remove();
            testerRoot.Save(testerPath);
        }
        public void updateTester(Tester T)
        {
            XElement testerElement;
            testerElement = (from p in testerRoot.Elements()
                             where p.Element("IDTester").Value == T.IDTester
                             select p).FirstOrDefault();
            if (testerElement == null)
                throw new Exception("The tester dosen't exsist in the system");
            testerElement.Element("IDTester").Value = T.IDTester;
            testerElement.Element("LastName").Value = T.LastName;
            testerElement.Element("FirstName").Value = T.FirstName;
            testerElement.Element("TesterGender").Value = T.TesterGender.ToString();
            testerElement.Element("Birth").Value = T.Birth.ToString();
            testerElement.Element("PhoneNumber").Value = T.PhoneNumber;
            testerElement.Element("TesterStreet").Value = T.TesterAdress.NameOfStreet;
            testerElement.Element("TesterNumStreet").Value = T.TesterAdress.NumOfStreet.ToString();
            testerElement.Element("TesterCity").Value = T.TesterAdress.city;
            testerElement.Element("Reputation").Value = T.Reputation.ToString();
            testerElement.Element("MaxTestsPerWeek").Value = T.MaxTestsPerWeek.ToString();
            testerElement.Element("FavoriteTester").Value = T.FavoriteTester.ToString();
            List<string> str = null;
            str = array2DToList(T.WorkTime);
            XElement WorkTime = new XElement("WorkTime", str.Select(i => new XElement("Time", i)));
            testerElement.Element("WorkTime").ReplaceWith(WorkTime);
            testerElement.Element("MaxDistance").Value = T.MaxDistance.ToString();
            if (T.TestDates != null)
            {
                XElement TestDates = new XElement("TestDates", T.TestDates.Select(i => new XElement("TimeTable", i)));
                testerElement.Element("TestDates").ReplaceWith(TestDates);
            }
            testerRoot.Save(testerPath);
        }
        public Tester getTester(string TesterID)
        {
            XElement p;
            p = (from q in testerRoot.Elements()
                 where q.Element("IDTester").Value == TesterID
                 select q).FirstOrDefault();
            if (p == null)
                throw new Exception("The tester dosen't exsist in the system");
            Tester T = new Tester()
            {
                IDTester = p.Element("IDTester").Value,
                LastName = p.Element("LastName").Value,
                FirstName = p.Element("FirstName").Value,
                TesterGender = (gender)Enum.Parse(typeof(gender), p.Element("TesterGender").Value),
                Birth = Convert.ToDateTime(p.Element("Birth").Value),
                PhoneNumber = p.Element("PhoneNumber").Value,
                TesterAdress = new adress(p.Element("TesterStreet").Value, Convert.ToInt32(p.Element("TesterNumStreet").Value), p.Element("TesterNumStreet").Value),
                Reputation = Convert.ToInt32(p.Element("Reputation").Value),
                MaxTestsPerWeek = Convert.ToInt32(p.Element("MaxTestsPerWeek").Value),
                FavoriteTester = (carType)Enum.Parse(typeof(carType), p.Element("FavoriteTester").Value),
                WorkTime = listTo2DArray(XMLToList(p.Element("WorkTime"))),
                MaxDistance = Convert.ToInt32(p.Element("MaxDistance").Value),
                TestDates = listToDate(XMLToList(p.Element("TestDates")))
            };
            return T;
        }
        public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)
        {
            IEnumerable<Tester> testers;
            try
            {

                testers = from p in testerRoot.Elements()
                          select new Tester()
                          {

                              IDTester = p.Element("IDTester").Value,
                              LastName = p.Element("LastName").Value,
                              FirstName = p.Element("FirstName").Value,
                              TesterGender = (gender)Enum.Parse(typeof(gender), p.Element("TesterGender").Value),
                              Birth = Convert.ToDateTime(p.Element("Birth").Value),
                              PhoneNumber = p.Element("PhoneNumber").Value,
                              TesterAdress = new adress(p.Element("TesterStreet").Value, Convert.ToInt32(p.Element("TesterNumStreet").Value), p.Element("TesterNumStreet").Value),
                              Reputation = Convert.ToInt32(p.Element("Reputation").Value),
                              MaxTestsPerWeek = Convert.ToInt32(p.Element("MaxTestsPerWeek").Value),
                              FavoriteTester = (carType)Enum.Parse(typeof(carType), p.Element("FavoriteTester").Value),
                              WorkTime = listTo2DArray(XMLToList(p.Element("WorkTime"))),
                              MaxDistance = Convert.ToInt32(p.Element("MaxDistance").Value),
                              TestDates = listToDate(XMLToList(p.Element("TestDates")))

                          };
                if (predicat != null)
                {
                    testers = testers.Where(predicat);
                }
            }
            catch
            {
                testers = null;
            }
            return testers;
        }
        #endregion
        #region Test
        /* *************
           *   Test    *
           *************  */

        public bool findTest(string ID)
        {
            XElement testElement;
            testElement = (from p in testRoot.Elements()
                           where p.Element("IDTest").Value == ID
                           select p).FirstOrDefault();
            if (testElement == null)
                return false;
            return true;
        }
        public void addTest(Test T)
        {
            string id = null;
            Configuration.TestID++;
            for (int j = 8; j > Configuration.TestID.ToString().Length; j--)
            {
                id = id + "0";
            }
            id = id + Configuration.TestID.ToString();
            T.IDTest = id;
            ConfigRoot.Element("TestID").Value = id;
            ConfigRoot.Save(ConfigPath);
            XElement IDTest = new XElement("IDTest", T.IDTest);
            XElement IDTester = new XElement("IDTester", T.IDTester);
            XElement IDTrainee = new XElement("IDTrainee", T.IDTrainee);
            XElement DateOfTest = new XElement("DateOfTest", T.DateOfTest);
            XElement TestStreet = new XElement("TestStreet", T.adressOfExit.NameOfStreet);
            XElement TestNumTest = new XElement("TestNumTest", T.adressOfExit.NumOfStreet);
            XElement TestCity = new XElement("TestCity", T.adressOfExit.city);
            XElement Grade = new XElement("Grade", false);
            testRoot.Add(new XElement("Test", IDTest, IDTester, IDTrainee, DateOfTest, TestStreet, TestNumTest, TestCity));
            testRoot.Save(testPath);
        }
        public void updateTest(Test T)
        {
            XElement testElement;
            testElement = (from p in testRoot.Elements()
                           where p.Element("IDTest").Value == T.IDTest
                           select p).FirstOrDefault();
            if (testElement == null)
                throw new Exception("The test dosen't exsist in the system");
            testElement.Element("IDTest").Value = T.IDTest;
            testElement.Element("IDTester").Value = T.IDTester;
            testElement.Element("IDTrainee").Value = T.IDTrainee;
            testElement.Element("DateOfTest").Value = T.DateOfTest.ToString();
            testElement.Element("TestStreet").Value = T.adressOfExit.NameOfStreet;
            testElement.Element("TestNumTest").Value = T.adressOfExit.NumOfStreet.ToString();
            testElement.Element("TestCity").Value = T.adressOfExit.city;
            testElement.Add(new XElement("KeepDistance", T.Grades.KeepDistance));
            testElement.Add(new XElement("ReversParking", T.Grades.ReversParking));
            testElement.Add(new XElement("Signaling", T.Grades.Signaling));
            testElement.Add(new XElement("MirrorLook", T.Grades.MirrorLook));
            testElement.Add(new XElement("PlanDrive", T.Grades.PlanDrive));
            testElement.Add(new XElement("TakingControl", T.Grades.TakingControl));
            testElement.Add(new XElement("GiveWay", T.Grades.GiveWay));
            testElement.Element("Grade").Value = T.Grade.ToString(); ;
            testElement.Add(new XElement("ReMark", T.ReMark));
            testRoot.Save(testPath);
        }
        public Test getTest(string ID)
        {
            XElement p;
            p = (from q in testRoot.Elements()
                 where q.Element("IDTest").Value == ID
                 select q).FirstOrDefault();
            if (p == null)
                throw new Exception("The test dosen't exsist in the system");
            Test T = new Test()
            {
                IDTest = p.Element("IDTest").Value,
                IDTester = p.Element("IDTester").Value,
                IDTrainee = p.Element("IDTrainee").Value,
                DateOfTest = Convert.ToDateTime(p.Element("DateOfTest").Value),
                adressOfExit = new adress(p.Element("TestStreet").Value, Convert.ToInt32(p.Element("TestNumTest").Value), p.Element("TestCity").Value),
                Grade = Convert.ToBoolean(p.Element("Grade").Value)
            };
            return T;
        }
        public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
        {
            IEnumerable<Test> tests;
            try
            {
                List<string> str = new List<string>();

                tests = from p in testRoot.Elements()
                        select new Test()
                        {
                            IDTest = p.Element("IDTest").Value,
                            IDTester = p.Element("IDTester").Value,
                            IDTrainee = p.Element("IDTrainee").Value,
                            DateOfTest = Convert.ToDateTime(p.Element("DateOfTest").Value),
                            adressOfExit = new adress(p.Element("TestStreet").Value, Convert.ToInt32(p.Element("TestNumTest").Value), p.Element("TestCity").Value),
                            Grades = new grade(Convert.ToBoolean(p.Element("KeepDistance").Value), Convert.ToBoolean(p.Element("ReversParking").Value), Convert.ToBoolean(p.Element("Signaling").Value), Convert.ToBoolean(p.Element("MirrorLook").Value), Convert.ToBoolean(p.Element("PlanDrive").Value), Convert.ToBoolean(p.Element("TakingControl").Value), Convert.ToBoolean(p.Element("GiveWay").Value)),
                            Grade = Convert.ToBoolean(p.Element("Grade").Value),
                            ReMark = p.Element("ReMark").Value
                        };
                if (predicat != null)
                {
                    tests = tests.Where(predicat);
                }
            }
            catch
            {
                tests = null;
            }
            return tests;


        }
        #endregion

        public List<Trainee> getListTrainee()
        {
            return getAllTrainee().ToList();
        }
        public List<Tester> getListTester()
        {
            return getAllTester().ToList();
        }
        public List<Test> getListTest()
        {
            return getAllTest().ToList();
        }
        public void SetConfig()
        {
            Configuration.MinLesson = Convert.ToInt32(ConfigRoot.Element("MinLesson").Value);
            Configuration.MinAgeTrainee = Convert.ToInt32(ConfigRoot.Element("MinAgeTrainee").Value);
            Configuration.MinAgeTester = Convert.ToInt32(ConfigRoot.Element("MinAgeTester").Value);
            Configuration.MaxAgeTester = Convert.ToInt32(ConfigRoot.Element("MaxAgeTester").Value);
            Configuration.TimeRange = Convert.ToInt32(ConfigRoot.Element("TimeRange").Value);
            Configuration.TestID = Convert.ToInt32(ConfigRoot.Element("TestID").Value);

        }
    }
}

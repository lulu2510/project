﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DS
{
    public class DataSource 
    {
        public static List<Trainee> trainees = new List<Trainee>();//list of trainees
        public static List<Tester> testers = new List<Tester>();//list of testers
        public static List<Test> tests = new List<Test>();//list of tests
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;


namespace BL
{
    public interface IBL
    {
        #region Trainee
        /* *************
          *  Trainee  *
          *************  */

        void addTrainee(Trainee T);//add trainee
        void deleteTrainee(string TraineeID);//delete Trainee
        void updateTrainee(Trainee T);//update Trainee
        Trainee GetTrainee(string TraineeID);
        IEnumerable <Trainee> getAllTrainee(Func<Trainee, bool> predicat = null);//get All Trainee
        int getTestCount(Trainee T);
        #endregion
        #region tester
        /* *************
           *  Tester  *
           *************  */

        void addTester(Tester T);//add Tester
        void deleteTester(string TesterID);//delete Tester
        void updateTester(Tester T);//update Tester
        List<Tester> Checkout(DateTime D);
        IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null);//get All Tester
        Tester GetTester(string ID);
        #endregion
        #region test
        /* *************
           *  Test  *
           *************  */

        void addTest(string ID, carType car, DateTime d, gear g);//add Test
        void updateTest(string TestID, string TesterID, bool[] grades);//update Test
        bool getResult(string TraineeID,string TestID);//get Test
        IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null);//get All Test
        #endregion 


        List<Trainee> getListTrainee();//מחזיר טבלה של כל התלמידים
        List<Tester> getListTester();//מחזיר טבלה של כל הבוחנים
        List<Test> getListTest();//מחזיר טבלה של כל המבחנים
        List<Test> getTodayTest();

        void SetConfig();
    }
}

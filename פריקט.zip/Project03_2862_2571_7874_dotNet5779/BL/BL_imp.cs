﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;

namespace BL
{   
    public class BL_imp : IBL
    {
        Idal dal = FactoryDalXml.getdal();//dalיצירת משתנה של

        #region Help Funcs
        int GetAge(DateTime d)//פונקציה שמחשבת גיל
        {
            int age;
            age = DateTime.Now.Year - d.Year;
            if (DateTime.Now.Month < d.Month)
                age--;
            if (DateTime.Now.Day < d.Day && DateTime.Now.Month == d.Month)
                age--;
            return age;
        }
        int GetDay(DateTime a, DateTime b)
        {
            int sum;
            sum = ((a.Year - b.Year) * 365) + ((a.Month - b.Month) * 30) + (a.Day - b.Day);
            return sum;
        }
        List<int> CheckDay(Tester T,DateTime d)
        {
            List<DateTime> a = new List<DateTime>();
            List<int> check = new List<int>();
            bool[] b = new bool[6];
            for (int i = 0; i < 6; i++)
            {
                b[i] = true;
            }
                for(int i =0;i< T.TestDates.Count; i++)
            {
                if (T.TestDates[i].Year == d.Year && T.TestDates[i].Month == d.Month && T.TestDates[i].Day == d.Day)
                    a.Add(T.TestDates[i]);
            }
            foreach (DateTime s in a)
            {
                for (int i = 0; i < 6; i++)
                {
                    if (s.Hour == 9+i || T.WorkTime[(int)d.DayOfWeek][i] == false)
                    {
                        b[i] = false;
                    }
                }
            }
            for (int i = 0; i < 6; i++)
            {
                if (b[i])
                    check.Add(i + 9);
            }
            return check;
        }
        List<Tester>CheckCarType(DateTime d,carType c,bool a)
        {
            List<Tester> Check = new List<Tester>();
            if (a)
            {
                List<Tester> t = Checkout(d);
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].FavoriteTester == c&&!MaxTest(d,t[i]))
                        Check.Add(t[i]);
                }
            }
            else
            {
                List<Tester> t = dal.getListTester();
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].FavoriteTester == c&&!MaxTest(d,t[i]))
                        Check.Add(t[i]);
                }
            }
            return Check;
        }
        DateTime getSunDayDate(DateTime d)
        {
            int a = (int)(d.DayOfWeek);
            a = -a;
            d = d.AddDays(a);
            return d;
        }
        bool MaxTest(DateTime d,Tester T)
        {
            d = getSunDayDate(d);
            int Max=0;
            if (T.TestDates != null)
            {
                foreach (DateTime s in T.TestDates)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 9; j < 16; j++)
                        {
                            if (s == d && s.Hour == j)
                                Max++;
                        }
                        d = d.AddDays(1);
                    }
                }
            }
            if (Max >= T.MaxTestsPerWeek)
                return true;
            return false;
        }
        #endregion
        #region trainee
        public void addTrainee(Trainee T)//פונקציה שבודקת אם הנתונים של התלמיד תקינים
        {
            if (GetAge(T.TraineeBirth) < Configuration.MinAgeTrainee)
            {
                throw new Exception("The trainne young than the appropriate age");
            }
            if (T.IDTrainee.Length != 9)
            {
                throw new Exception("Wrong ID");
            }
            if(T.TraineePhone.Length != 10)
            {
                throw new Exception("Wrong phone number");
            }
            dal.addTrainee(T);//dalשולח את הנתונים ל
        }
        public void deleteTrainee(string TraineeID)//מוחק תלמיד
        {
            dal.deleteTrainee(TraineeID);
        }
        public void updateTrainee(Trainee T)//בדיקת קלט אחרי עדכון
        {
            if (GetAge(T.TraineeBirth) < Configuration.MinAgeTrainee)
            {
                throw new Exception("The trainne young than the appropriate age");
            }
            if (T.TraineePhone.Length != 10)
            {
                throw new Exception("Wrong phone number");
            }
            dal.updateTrainee(T);//dalשולח את הנתונים ל
        }
        public IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null)//פונקציה שמחזירה טבלה של כל התלמידים
        {
            return dal.getAllTrainee(predicat);
        }
        public int getTestCount(Trainee T)
        {
            return T.TestCounts;
        }
        public Trainee GetTrainee(string TraineeID)
        {
            return dal.getTrainee(TraineeID);
        }
        #endregion
        #region tester
        public void addTester(Tester T)//פונקציה שבודקת אם הנתונים של הבוחן תקינים
        {
            if (GetAge(T.Birth) < Configuration.MinAgeTester)
            {
                throw new Exception("The tester young than the appropriate age");
            }
            if (GetAge(T.Birth) > Configuration.MaxAgeTester)
            {
                throw new Exception("The tester old than the appropriate age");
            }
            if (T.IDTester.Length != 9)
            {
                throw new Exception("Wrong ID");
            }
            if (T.PhoneNumber.Length != 10)
            {
                throw new Exception("Wrong phone number");
            }
            dal.addTester(T);
        }
        public void deleteTester(string TesterID)//מחיקת בוחן
        {
            dal.deleteTester(TesterID);
        }
        public void updateTester(Tester T)//בדיקת קלט אחרי עדכון
        {
            if (GetAge(T.Birth) < Configuration.MinAgeTester)
            {
                throw new Exception("The tester young than the appropriate age");
            }
            if (GetAge(T.Birth) > Configuration.MaxAgeTester)
            {    
                throw new Exception("The tester old than the appropriate age");
            }
            if (T.PhoneNumber.Length != 10)
            {
                throw new Exception("Wrong phone number");
            }
            dal.updateTester(T);
        }
        public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)//פונקציה שמחזירה טבלה של כל הבוחנים
        {
            return dal.getAllTester(predicat);
        }
        public List<Tester> Checkout(DateTime D)
        {
            List<Tester> Testers = dal.getListTester();
            List<Tester> testers = new List<Tester>();
            for(int i =0; i<Testers.Count;i++)
            {
                
                if (Testers[i].TestDates == null && Testers[i].WorkTime[(int)D.DayOfWeek][D.Hour] == true)
                {
                    testers.Add(Testers[i]);
                }
                if (Testers[i].TestDates != null)
                {
                    foreach (DateTime s in Testers[i].TestDates)
                        if (s != D && Testers[i].WorkTime[(int)D.DayOfWeek][D.Hour-9] == true)
                        {
                            testers.Add(Testers[i]);
                        }
                }
            }
            return testers;
        }
        public Tester GetTester(string ID)
        {
            return dal.getTester(ID);
        }
        #endregion
        #region test
        public void addTest(string ID, carType car, DateTime d,gear g)
        {
            Trainee T = dal.getTrainee(ID);
            if (T.LastTestDate != null)
            {
                if (GetDay(d, T.LastTestDate) < Configuration.TimeRange)
                {
                    throw new Exception("You need to wait enough time for the next test");
                }
            }
            if (T.LessonCount < Configuration.MinLesson)
            {
                throw new Exception("You need to do " + Configuration.MinLesson + " lesson");
            }
            if (T.carTypeAvar[(int)car] != false)
            {
                throw new Exception("you can not do test on car that you sucsses test");
            }
            if(T.TraineeCarType!=car)
            {
                throw new Exception("you can not do test on diffrent car than you learn");
            }
            if((int)d.DayOfWeek>4)
            {
                throw new Exception("You cannot add test in weekend");
            }
            if (CheckCarType(d, car, true).Count == 0)
            {
                List<Tester> Testers = CheckCarType(d, car, false);
                foreach (Tester Te in Testers)
                {
                    List<int> Check = CheckDay(Te, d);
                    if (Check.Count !=0)
                    {
                        throw new Exception("We could'nt find any testers at this time. You can take the test in " + Check.First() +":00 at the same day ");
                    } 
                }
                throw new Exception("We coun't find a tester readily available for today. Please check another date.");
            }
            List<Test> Tests = dal.getListTest();
            foreach(Test tests in Tests)
            {
                if (ID == tests.IDTrainee && d == tests.DateOfTest)
                    throw new Exception("You can't do 2 tests in same time");
            }
            Tester testerForTest = new Tester();
            testerForTest =  CheckCarType(d, car, true).FirstOrDefault();
            if(testerForTest.TestDates==null)
                testerForTest.TestDates = new List<DateTime>();
            if (d != null)
            {
                testerForTest.TestDates.Add(d);
            }
            updateTester(testerForTest);
            Test test = new Test();
            Trainee trainee = new Trainee();
            trainee = dal.getTrainee(ID);
            trainee.LastTestDate= d;
            trainee.TestCounts++;
            dal.updateTrainee(trainee);
            test.IDTrainee = ID;
            test.IDTester = testerForTest.IDTester;
            test.DateOfTest = d;
            test.adressOfExit = T.TraineeAdress;
            T.TestCounts++;
            dal.addTest(test);

        }
        public void updateTest(string TestID,string TesterID, bool[] grades)
        {
            Test T = dal.getTest(TestID);
            if (T.IDTester != TesterID)
                throw new Exception("You cannot update test if you not the tester");
            if (GetDay(DateTime.Now, T.DateOfTest) < 0 || (GetDay(DateTime.Now, T.DateOfTest) == 0 && DateTime.Now.Hour <= T.DateOfTest.Hour))
                throw new Exception("You can not update test before the test done");
            T.Grades = new grade(grades[0], grades[1], grades[2], grades[3], grades[4], grades[5], grades[6]);
            int sum = 0;
            for(int i=0;i<5;i++)
            {
                if(!grades[i])
                {
                    sum++;
                }
            }
            if (!grades[5] || !grades[6] || sum > 2)
                T.Grade = false;
            else
                T.Grade = true;
            dal.updateTest(T);
        }
        public bool getResult(string TraineeID, string TestID)
        {
            Test T = dal.getTest(TestID);
            if(T.IDTrainee != TraineeID)
            {
                throw new Exception("Authentication failed");
            }
            return T.Grade;
        }
        public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
        {
            return dal.getAllTest(predicat);
        }
        #endregion  
        
        public List<Trainee> getListTrainee()
        {
            return dal.getListTrainee();
        }
        public List<Tester> getListTester()
        {
            return dal.getListTester();
        }
        public List<Test> getListTest()
        {
            return dal.getListTest();
        }
        public List<Test> getTodayTest()
        {
            List<Test> t = dal.getListTest();
            List<Test> test = null;
            foreach (Test T in t)
            {
                if (T.DateOfTest == DateTime.Now)
                    test.Add(T);
            }
            return test;
        }

        public void SetConfig()
        {
            dal.SetConfig();
        }
    }
}
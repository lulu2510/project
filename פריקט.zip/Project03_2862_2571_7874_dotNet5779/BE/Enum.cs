﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BE//enum לתוכנית
{
    public enum gender    { male, female};                                                      //gender
    public enum carType { PrivateCar, twoWheeled, mediumTruck, bigTruck };               //car type
    public enum gear      { automatic, manual};                                               //gear
    public enum DayOfWeek { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday};  // DayOfWeek
    public enum success   { failes,success};                                              //success
}

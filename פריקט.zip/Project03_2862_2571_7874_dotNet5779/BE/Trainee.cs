﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BE
{
    public class Trainee
    {
        
        public string IDTrainee { get; set; } //Trainee ID
        public string FirstNameTrainee { get; set; } //Trainee First name
        public string LastNameTrainee { get; set; } //Trainee Last name
        public gender TraineeGender { get; set; } //Trainee gender
        public string TraineePhone { get; set; } //Trainee phone
        public adress TraineeAdress { get; set; } = new adress(null, 0, null); //Trainee adress
        public DateTime TraineeBirth { get; set; } //Trainee birth
        public carType  TraineeCarType { get; set; } //Trainee car type
        public gear TraineeGear { get; set; } //Trainee gear
        public string TraineeSchool { get; set; } //Trainee school
        public string NameTeacher { get; set; } //Teacher name
        public int LessonCount { get; set; } //Trainee count lessons
        public DateTime LastTestDate { get; set; }//LastTestDate
        public int TestCounts { get; set; }//Test Counts
        public bool[] carTypeAvar = new bool[4];
        public override string ToString()
        {
            return base.ToString();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BE
{
    public class Tester
    {
        public string IDTester { get; set; } //id number
        public string LastName { get; set; } //last name
        public string FirstName { get; set; }//first nam
        public gender TesterGender { get; set; } //Tester gender
        public DateTime Birth { get; set; }//brith date
        public string PhoneNumber { get; set; }//phone number
        public adress TesterAdress { get; set; } = new adress(null, 0, null);//adress
        public int Reputation { get; set; }//reputation
        public int MaxTestsPerWeek { get; set; }//maxTestsPerWeek
        public carType FavoriteTester { get; set; }//favoriteTester
        public bool[][] WorkTime { get; set; } = { new bool[6], new bool[6], new bool[6], new bool[6], new bool[6]};//worktime
        public int MaxDistance { get; set; }//maxDistance
        public List<DateTime> TestDates { get; set; }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}

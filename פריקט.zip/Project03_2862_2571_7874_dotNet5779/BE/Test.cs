﻿using System;
namespace BE
{
    public class Test
    {
        public string IDTest { get; set; } // test number
        public string IDTester { get; set; }// tester id number
        public string IDTrainee { get; set; } // trainee id number
        public DateTime DateOfTest { get; set; }//the date of the test
        public adress adressOfExit { get; set; }//Exit test adress 
        public grade Grades { get; set; }
        public bool Grade { get; set; }
        public string ReMark { get; set; } //Tester ReMark
        public override string ToString()
        {
            return "ab";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BE//קלאסים לעזרה
{
        //Adress Class
        public class adress
        {
            public string NameOfStreet { get; set; }
            public int NumOfStreet { get; set; }
            public string city { get; set; }
            public adress(string a, int b, string c)
            {
                NameOfStreet = a;
                NumOfStreet = b;
                city = c;
            }
        };
    // Grade class
    public class grade
    {
        public bool KeepDistance { get; set; }
        public bool ReversParking { get; set; }
        public bool Signaling { get; set; }
        public bool MirrorLook { get; set; }
        public bool PlanDrive { get; set; }
        public bool TakingControl { get; set; }
        public bool GiveWay { get; set; }
        public grade(bool a, bool b, bool c, bool d, bool e, bool f,bool g)
        {
            KeepDistance = a;
            ReversParking = b;
            Signaling = c;
            MirrorLook = d;
            PlanDrive = e;
            TakingControl = f;
            GiveWay = g;
        }
    };

}

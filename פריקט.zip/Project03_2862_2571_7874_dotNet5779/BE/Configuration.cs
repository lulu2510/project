﻿using System;
using System.Collections.Generic;
using System.Text;


namespace BE//נתונים בסיסיים
{
    public class Configuration
    {
        
        public static int MinLesson;
        public static int MinAgeTrainee;
        public static int MinAgeTester;
        public static int TimeRange;
        public static int MaxAgeTester;
        public static int TestID;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UpdateTester.xaml
    /// </summary>
    public partial class UpdateTester : Window
    {
        IBL bl;
        Tester tester;
        public UpdateTester()
        {
            InitializeComponent();
            this.Gender.ItemsSource = Enum.GetValues(typeof(BE.gender));
            this.Cartype.ItemsSource = Enum.GetValues(typeof(BE.carType));
            bl = FactoryBL.getBL();
            tester = new Tester();
            DataContext = tester;
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.updateTester(tester);
                MessageBox.Show("Sucsses");
                tester = new Tester();
                this.DataContext = tester;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void IDNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (IDNumber.Text != "")
            {
                try
                {
                    int a = Convert.ToInt32(IDNumber.Text);
                }
                catch
                {
                    IDNumber.Text = "";
                    MessageBox.Show("ID must be only digits");
                }
                if (this.IDNumber.Text.Length == 9)
                    try
                    {
                        tester = new Tester();
                        tester = bl.GetTester(this.IDNumber.Text);
                        this.DataContext = tester;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
            }
        }
    }
}

﻿using BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UpdateTest.xaml
    /// </summary>
    public partial class UpdateTest : Window
    {
        IBL bl;
        public UpdateTest()
        {
            InitializeComponent();
            this.Signalinganswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            this.reverseparkinganswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            this.plandriveanswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            this.lookatthemirrorsanswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            this.expropriationofcontrolanswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            this.givingrightowayanswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            this.keepdistanceanswer.ItemsSource = Enum.GetValues(typeof(BE.success));
            bl = FactoryBL.getBL();
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Givingrightowayanswer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool[] arr = new bool[7];
                arr[0] = Convert.ToBoolean(Convert.ToInt16(keepdistanceanswer.SelectedIndex)); 
                arr[1] = Convert.ToBoolean(Convert.ToInt16(reverseparkinganswer.SelectedIndex));
                arr[2] = Convert.ToBoolean(Convert.ToInt16(Signalinganswer.SelectedIndex));
                arr[3] = Convert.ToBoolean(Convert.ToInt16(lookatthemirrorsanswer.SelectedIndex));
                arr[4] = Convert.ToBoolean(Convert.ToInt16(plandriveanswer.SelectedIndex));
                arr[5] = Convert.ToBoolean(Convert.ToInt16(expropriationofcontrolanswer.SelectedIndex));
                arr[6] = Convert.ToBoolean(Convert.ToInt16(givingrightowayanswer.SelectedIndex));
                bl.updateTest(idnumberanswer.Text, testnumberanswer.Text, arr);
                MessageBox.Show("Sucsses");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

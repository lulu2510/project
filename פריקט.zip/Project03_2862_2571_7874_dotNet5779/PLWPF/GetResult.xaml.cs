﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BL;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for GetResualt.xaml
    /// </summary>
    public partial class GetResult : Window
    {
        IBL bl;
        public GetResult()
        {
            InitializeComponent();
            bl = FactoryBL.getBL();
        }

        private void GetResult_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (bl.getResult(ID.Text, Testnumber.Text))
                    MessageBox.Show("You sucsses in The Test");
                else
                    MessageBox.Show("You failed in The Test");

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddTest.xaml
    /// </summary> 
    public partial class AddTest : Window
    {
        IBL bl;
        public AddTest()
        {
            InitializeComponent();
            bl = FactoryBL.getBL();
            this.Answercartype.ItemsSource = Enum.GetValues(typeof(BE.carType));
            this.Answergearbox.ItemsSource = Enum.GetValues(typeof(BE.gear));
            for (int i = 9; i < 16; i++)
            {
                if (i == 9)
                    this.time.Items.Add("09:00");
                else
                    this.time.Items.Add(i + ":00");
            }

        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime d = new DateTime();
                d = Convert.ToDateTime(this.date.SelectedDate);
                int sum = time.SelectedIndex + 9;
                d = d.AddHours(sum);
                carType c = (carType)Answercartype.SelectedIndex;
                gear g = (gear)Answergearbox.SelectedIndex;
                bl.addTest(this.IDNumber.Text, c, d, g);
                string id = null;
                for (int j = 8; j > Configuration.TestID.ToString().Length; j--)
                {
                    id = id + "0";
                }
                id = id + Configuration.TestID.ToString();
                throw new Exception("The Test Added. Your Test ID is: " + id);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

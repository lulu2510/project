﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for MainTraineeScreen.xaml
    /// </summary>
    public partial class MainTraineeScreen : Window
    {
        public MainTraineeScreen()
        {
            InitializeComponent();
        }

        private void Addnewtraineeclick(object sender, RoutedEventArgs e)
        {
            new AddTrainee().ShowDialog();
        }

        private void Updatetraineeclick(object sender, RoutedEventArgs e)
        {
            new UpdateTrainee().ShowDialog();
        }

        private void Deletetraineeclick(object sender, RoutedEventArgs e)
        {
            new DeleteTrainee().ShowDialog();
        }

        private void Newtestclick(object sender, RoutedEventArgs e)
        {
            new AddTest().ShowDialog();
        }

        private void Getresultclick(object sender, RoutedEventArgs e)
        {
            new GetResult().ShowDialog();
        }

        private void Getalltraineesclick(object sender, RoutedEventArgs e)
        {

        }

        private void Exitclick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

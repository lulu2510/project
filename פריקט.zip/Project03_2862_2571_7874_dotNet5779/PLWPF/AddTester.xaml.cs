﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddTester.xaml
    /// </summary>
    public partial class AddTester : Window
    {
        IBL bl;
        Tester tester;
        public AddTester()
        {

            InitializeComponent();
            tester = new Tester();
            this.Addtester.DataContext = tester;
            bl = FactoryBL.getBL();
            this.Cartype.ItemsSource = Enum.GetValues(typeof(carType));
            this.Gender.ItemsSource = Enum.GetValues(typeof(gender));
        }

            
        
        private void exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.addTester(tester);
                MessageBox.Show("The Tester " + tester.FirstName + " added in sucssesfull");
                tester = new Tester();
                this.Addtester.DataContext = tester;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UpdateTrainee.xaml
    /// </summary>
    public partial class UpdateTrainee : Window
    {
        IBL bl;
        Trainee trainee;
        public UpdateTrainee()
        {
            InitializeComponent();
            this.Answergender.ItemsSource = Enum.GetValues(typeof(BE.gender));
            this.Answergearbox.ItemsSource = Enum.GetValues(typeof(BE.gear));
            this.Answercartype.ItemsSource = Enum.GetValues(typeof(BE.carType));
            trainee = new Trainee();
            bl = FactoryBL.getBL();
            this.DataContext = trainee;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.updateTrainee(trainee);
                MessageBox.Show("Sucsses");
                trainee = new Trainee();
                this.DataContext = trainee;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ID_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            if (ID.Text != "")
            {
                try
                {
                    int a = Convert.ToInt32(ID.Text);
                }
                catch
                {
                    ID.Text = "";
                    MessageBox.Show("ID must be only digits");
                }
                if (this.ID.Text.Length == 9)
                    try
                    {
                        trainee = new Trainee();
                        trainee = bl.GetTrainee(this.ID.Text);
                        this.DataContext = trainee;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
            }
        }
    }
}

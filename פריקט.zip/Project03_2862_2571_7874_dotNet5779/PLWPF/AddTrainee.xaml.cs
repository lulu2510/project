﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddTrainee.xaml
    /// </summary>
    public partial class AddTrainee : Window
    {
        Trainee trainee;
        IBL bl;
        public AddTrainee()
        {
            InitializeComponent();
            trainee = new Trainee();
            this.Addtrainee.DataContext = trainee;
            bl = FactoryBL.getBL();
            this.Answergender.ItemsSource = Enum.GetValues(typeof(gender));
            this.Answergearbox.ItemsSource = Enum.GetValues(typeof(gear));
            this.Answercartype.ItemsSource = Enum.GetValues(typeof(carType));
            
            
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bl.addTrainee(trainee);
                MessageBox.Show("The Trainee " + trainee.FirstNameTrainee + " added in sucssesfull");
                trainee = new Trainee();
                this.Addtrainee.DataContext = trainee;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void street_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

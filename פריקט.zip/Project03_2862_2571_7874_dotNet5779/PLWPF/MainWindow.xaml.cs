﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BL;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        IBL bl;
        public MainWindow()
        {
            InitializeComponent();
            bl = FactoryBL.getBL();
            bl.SetConfig();
        }

        private void traineeclick(object sender, RoutedEventArgs e)
        {
            new MainTraineeScreen().ShowDialog();
        }

        private void testerclick(object sender, RoutedEventArgs e)
        {
            new MainTesterScreen().ShowDialog();
        }

        private void exitclick(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}

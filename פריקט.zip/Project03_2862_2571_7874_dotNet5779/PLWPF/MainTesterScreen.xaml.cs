﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for MainTesterScreen.xaml
    /// </summary>
    public partial class MainTesterScreen : Window
    {
        public MainTesterScreen()
        {
            InitializeComponent();
        }

        private void addnewtesterclick(object sender, RoutedEventArgs e)
        {
            new AddTester().ShowDialog();
        }

        private void updatetesterclick(object sender, RoutedEventArgs e)
        {
            new UpdateTester().ShowDialog();
        }

        private void deletetesterclick(object sender, RoutedEventArgs e)
        {
            new DeleteTester().ShowDialog();
        }

        private void newtestclick(object sender, RoutedEventArgs e)
        {
            new UpdateTest().ShowDialog();
        }

        private void testlistclick(object sender, RoutedEventArgs e)
        {

        }

        private void getalltestersclick(object sender, RoutedEventArgs e)
        {

        }

        private void exitclick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
